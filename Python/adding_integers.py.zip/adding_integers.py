# Adding two numbers(integer type)

# user input
#number_1 = eval(input())
#number_2 = eval(input())

# normal values
number_1 = 45
number_2 = 67

sum_of_numbers = number_1 + number_2

print(sum_of_numbers)
